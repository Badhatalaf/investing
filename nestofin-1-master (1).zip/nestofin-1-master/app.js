const express = require('express');
const app = express();

app.set('view engine','ejs');
app.use(express.urlencoded({extended: true}));
app.use(express.static("public"));


app.get("/", function(req,res) {
  res.render("index");
})

app.get("/learnmore", function(req,res){
  res.render("learnmore");
})

app.get("/orders", function(req,res) {
  res.render("orders");
})

app.listen(3000, ()=>{
  console.log('server started on port 3000');
});
