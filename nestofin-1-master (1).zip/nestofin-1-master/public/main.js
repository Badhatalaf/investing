const dropdown = document.getElementById('dropdown');
const close = document.getElementById('close');
const bar = document.getElementById('bars');
const minus = document.getElementById("minus");
const plus = document.getElementById("plus");
const counter = document.getElementById("inc-dec");
const amount = document.getElementById("amount");

i = 0;

bar.addEventListener('click', () => {
  dropdown.style.display = 'flex';
  bar.style.display = 'none'
  close.style.display = 'flex'
});

close.addEventListener('click', () => {
  dropdown.style.display = 'none';
  bar.style.display = 'flex'
  close.style.display = 'none'
});

plus.addEventListener("click", function() {
  i++;
  counter.innerHTML = "Quantity: " + i;
  amount.innerHTML = "Amount: " + i * 4 + " rupees";
});

minus.addEventListener("click", function() {
  if (i === 0) {
    counter.innerHTML = "Quantity: 0";
    amount.innerHTML = "Amount: 0 rupee";
  } else {
    i--;
    counter.innerHTML = "Quantity: " + i;
    amount.innerHTML = "Amount: " + i * 4 + " rupees";
  }
});
